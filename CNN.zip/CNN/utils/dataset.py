import torch
from torch.utils.data import Dataset, DataLoader
import numpy as np
import h5py
import os
from pathlib import Path


class SpectralDataset(Dataset):
    def __init__(self, data_path, transform=None, normalize=True):
        self.data_path = Path(data_path)
        self.transform = transform
        self.normalize = normalize
        
        self.file_list = []
        if self.data_path.exists():
            self.file_list = list(self.data_path.glob('*.h5')) + list(self.data_path.glob('*.npy'))
        
        if len(self.file_list) == 0:
            print(f"Warning: No data files found in {data_path}")
    
    def __len__(self):
        return len(self.file_list)
    
    def __getitem__(self, idx):
        file_path = self.file_list[idx]
        
        if file_path.suffix == '.h5':
            with h5py.File(file_path, 'r') as f:
                lyso_spectrum = f['lyso'][:]
                hpge_spectrum = f['hpge'][:]
        else:
            data = np.load(file_path)
            lyso_spectrum = data['lyso']
            hpge_spectrum = data['hpge']
        
        lyso_spectrum = lyso_spectrum.astype(np.float32)
        hpge_spectrum = hpge_spectrum.astype(np.float32)
        
        if self.normalize:
            lyso_spectrum = lyso_spectrum / (np.max(lyso_spectrum) + 1e-8)
            hpge_spectrum = hpge_spectrum / (np.max(hpge_spectrum) + 1e-8)
        
        lyso_tensor = torch.from_numpy(lyso_spectrum).unsqueeze(0)
        hpge_tensor = torch.from_numpy(hpge_spectrum).unsqueeze(0)
        
        if self.transform:
            lyso_tensor = self.transform(lyso_tensor)
            hpge_tensor = self.transform(hpge_tensor)
        
        return lyso_tensor, hpge_tensor


def create_data_loaders(train_path, val_path, batch_size=32, num_workers=4):
    train_dataset = SpectralDataset(train_path)
    val_dataset = SpectralDataset(val_path)
    
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=True
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True
    )
    
    return train_loader, val_loader