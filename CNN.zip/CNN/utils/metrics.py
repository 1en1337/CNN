import numpy as np
import torch
from scipy.signal import find_peaks
from scipy.interpolate import interp1d
from scipy.optimize import curve_fit


def gaussian(x, amp, cen, wid):
    return amp * np.exp(-(x-cen)**2 / (2*wid**2))


def calculate_fwhm(spectrum, channel_axis=None):
    if isinstance(spectrum, torch.Tensor):
        spectrum = spectrum.detach().cpu().numpy()
    
    if len(spectrum.shape) == 3:
        spectrum = spectrum[0, 0, :]
    elif len(spectrum.shape) == 2:
        spectrum = spectrum[0, :]
    
    peaks, properties = find_peaks(spectrum, height=np.max(spectrum)*0.3, distance=50)
    
    if len(peaks) == 0:
        return None, None
    
    main_peak_idx = peaks[np.argmax(spectrum[peaks])]
    peak_height = spectrum[main_peak_idx]
    half_height = peak_height / 2
    
    left_idx = main_peak_idx
    while left_idx > 0 and spectrum[left_idx] > half_height:
        left_idx -= 1
    
    right_idx = main_peak_idx
    while right_idx < len(spectrum) - 1 and spectrum[right_idx] > half_height:
        right_idx += 1
    
    if left_idx > 0 and right_idx < len(spectrum) - 1:
        x = np.arange(left_idx-10, right_idx+10)
        y = spectrum[left_idx-10:right_idx+10]
        
        try:
            popt, _ = curve_fit(gaussian, x, y, p0=[peak_height, main_peak_idx, 10])
            fwhm = 2.355 * abs(popt[2])
            return fwhm, main_peak_idx
        except:
            fwhm = right_idx - left_idx
            return fwhm, main_peak_idx
    
    return None, None


def calculate_peak_centroid(spectrum):
    if isinstance(spectrum, torch.Tensor):
        spectrum = spectrum.detach().cpu().numpy()
    
    if len(spectrum.shape) == 3:
        spectrum = spectrum[0, 0, :]
    elif len(spectrum.shape) == 2:
        spectrum = spectrum[0, :]
    
    peaks, _ = find_peaks(spectrum, height=np.max(spectrum)*0.3, distance=50)
    
    if len(peaks) == 0:
        return None
    
    main_peak_idx = peaks[np.argmax(spectrum[peaks])]
    
    window = 20
    start = max(0, main_peak_idx - window)
    end = min(len(spectrum), main_peak_idx + window)
    
    x = np.arange(start, end)
    y = spectrum[start:end]
    
    centroid = np.sum(x * y) / np.sum(y)
    
    return centroid


def calculate_peak_to_compton(spectrum):
    if isinstance(spectrum, torch.Tensor):
        spectrum = spectrum.detach().cpu().numpy()
    
    if len(spectrum.shape) == 3:
        spectrum = spectrum[0, 0, :]
    elif len(spectrum.shape) == 2:
        spectrum = spectrum[0, :]
    
    peaks, _ = find_peaks(spectrum, height=np.max(spectrum)*0.3, distance=50)
    
    if len(peaks) == 0:
        return None
    
    main_peak_idx = peaks[np.argmax(spectrum[peaks])]
    peak_value = spectrum[main_peak_idx]
    
    compton_region_start = max(0, int(main_peak_idx * 0.3))
    compton_region_end = int(main_peak_idx * 0.7)
    
    if compton_region_end > compton_region_start:
        compton_value = np.mean(spectrum[compton_region_start:compton_region_end])
        peak_to_compton = peak_value / (compton_value + 1e-8)
        return peak_to_compton
    
    return None


class SpectralMetrics:
    @staticmethod
    def compute_all_metrics(pred_spectrum, target_spectrum, original_spectrum=None):
        metrics = {}
        
        fwhm_pred, peak_idx_pred = calculate_fwhm(pred_spectrum)
        fwhm_target, peak_idx_target = calculate_fwhm(target_spectrum)
        
        if fwhm_pred is not None and fwhm_target is not None:
            metrics['fwhm_pred'] = fwhm_pred
            metrics['fwhm_target'] = fwhm_target
            metrics['fwhm_improvement'] = (fwhm_target - fwhm_pred) / fwhm_target * 100
        
        if original_spectrum is not None:
            fwhm_original, _ = calculate_fwhm(original_spectrum)
            if fwhm_original is not None and fwhm_pred is not None:
                metrics['fwhm_original'] = fwhm_original
                metrics['fwhm_reduction'] = (fwhm_original - fwhm_pred) / fwhm_original * 100
        
        centroid_pred = calculate_peak_centroid(pred_spectrum)
        centroid_target = calculate_peak_centroid(target_spectrum)
        
        if centroid_pred is not None and centroid_target is not None:
            metrics['centroid_pred'] = centroid_pred
            metrics['centroid_target'] = centroid_target
            metrics['centroid_shift'] = abs(centroid_pred - centroid_target)
        
        ptc_pred = calculate_peak_to_compton(pred_spectrum)
        ptc_target = calculate_peak_to_compton(target_spectrum)
        
        if ptc_pred is not None and ptc_target is not None:
            metrics['peak_to_compton_pred'] = ptc_pred
            metrics['peak_to_compton_target'] = ptc_target
            metrics['ptc_improvement'] = (ptc_pred - ptc_target) / ptc_target * 100
        
        return metrics