import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from scipy.signal import find_peaks


class SpectralCompositeLoss(nn.Module):
    def __init__(self, peak_weight=10.0, compton_weight=1.0, smoothness_weight=0.1):
        super(SpectralCompositeLoss, self).__init__()
        self.peak_weight = peak_weight
        self.compton_weight = compton_weight
        self.smoothness_weight = smoothness_weight
        
    def find_peak_regions(self, spectrum):
        spectrum_np = spectrum.detach().cpu().numpy()
        batch_size = spectrum_np.shape[0]
        peak_masks = []
        
        for i in range(batch_size):
            spec = spectrum_np[i, 0, :]
            peaks, properties = find_peaks(spec, height=np.max(spec)*0.1, distance=20)
            
            mask = np.zeros_like(spec)
            for peak in peaks:
                start = max(0, peak - 50)
                end = min(len(spec), peak + 50)
                mask[start:end] = 1.0
            
            peak_masks.append(mask)
        
        peak_masks = np.stack(peak_masks)
        return torch.tensor(peak_masks, device=spectrum.device, dtype=torch.float32).unsqueeze(1)
    
    def forward(self, pred, target):
        mse_loss = F.mse_loss(pred, target, reduction='none')
        
        peak_mask = self.find_peak_regions(target)
        compton_mask = 1.0 - peak_mask
        
        peak_loss = (mse_loss * peak_mask).mean()
        compton_loss = (mse_loss * compton_mask).mean()
        
        smoothness_loss = torch.mean(torch.abs(pred[:, :, 1:] - pred[:, :, :-1]))
        
        total_loss = (self.peak_weight * peak_loss + 
                     self.compton_weight * compton_loss + 
                     self.smoothness_weight * smoothness_loss)
        
        return total_loss, {
            'peak_loss': peak_loss.item(),
            'compton_loss': compton_loss.item(),
            'smoothness_loss': smoothness_loss.item(),
            'total_loss': total_loss.item()
        }