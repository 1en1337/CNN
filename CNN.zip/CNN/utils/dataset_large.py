import torch
from torch.utils.data import Dataset, DataLoader, IterableDataset
import numpy as np
import h5py
import os
from pathlib import Path
import random
import pickle
from concurrent.futures import ThreadPoolExecutor
import threading
from collections import deque
import mmap
import lmdb


class LargeSpectralDataset(Dataset):
    """优化版Dataset，支持百万级数据量"""
    
    def __init__(self, data_path, transform=None, normalize=True, 
                 index_cache_path=None, use_mmap=True):
        self.data_path = Path(data_path)
        self.transform = transform
        self.normalize = normalize
        self.use_mmap = use_mmap
        self.index_cache_path = index_cache_path or self.data_path / '.index_cache.pkl'
        
        self._build_index()
        
    def _build_index(self):
        """构建文件索引，支持缓存"""
        if self.index_cache_path.exists():
            print(f"Loading index from cache: {self.index_cache_path}")
            with open(self.index_cache_path, 'rb') as f:
                self.file_index = pickle.load(f)
        else:
            print("Building file index...")
            self.file_index = []
            
            for file_path in self.data_path.rglob('*.h5'):
                self.file_index.append(str(file_path))
            for file_path in self.data_path.rglob('*.npy'):
                self.file_index.append(str(file_path))
            
            print(f"Found {len(self.file_index)} files")
            
            # 保存索引缓存
            with open(self.index_cache_path, 'wb') as f:
                pickle.dump(self.file_index, f)
    
    def __len__(self):
        return len(self.file_index)
    
    def __getitem__(self, idx):
        file_path = self.file_index[idx]
        
        try:
            if file_path.endswith('.h5'):
                with h5py.File(file_path, 'r', libver='latest', swmr=True) as f:
                    lyso_spectrum = f['lyso'][:]
                    hpge_spectrum = f['hpge'][:]
            else:
                if self.use_mmap:
                    # 使用内存映射加速
                    data = np.load(file_path, mmap_mode='r')
                else:
                    data = np.load(file_path)
                lyso_spectrum = data['lyso']
                hpge_spectrum = data['hpge']
            
            lyso_spectrum = lyso_spectrum.astype(np.float32)
            hpge_spectrum = hpge_spectrum.astype(np.float32)
            
            if self.normalize:
                lyso_spectrum = lyso_spectrum / (np.max(lyso_spectrum) + 1e-8)
                hpge_spectrum = hpge_spectrum / (np.max(hpge_spectrum) + 1e-8)
            
            lyso_tensor = torch.from_numpy(lyso_spectrum).unsqueeze(0)
            hpge_tensor = torch.from_numpy(hpge_spectrum).unsqueeze(0)
            
            if self.transform:
                lyso_tensor = self.transform(lyso_tensor)
                hpge_tensor = self.transform(hpge_tensor)
            
            return lyso_tensor, hpge_tensor
            
        except Exception as e:
            print(f"Error loading {file_path}: {e}")
            # 返回零张量避免训练中断
            return torch.zeros(1, 4096), torch.zeros(1, 4096)


class StreamingSpectralDataset(IterableDataset):
    """流式数据集，适合超大规模数据"""
    
    def __init__(self, data_path, transform=None, normalize=True, 
                 buffer_size=1000, num_workers=4):
        self.data_path = Path(data_path)
        self.transform = transform
        self.normalize = normalize
        self.buffer_size = buffer_size
        self.num_workers = num_workers
        
    def __iter__(self):
        worker_info = torch.utils.data.get_worker_info()
        
        # 获取所有文件列表
        file_list = []
        for pattern in ['*.h5', '*.npy']:
            file_list.extend(self.data_path.rglob(pattern))
        
        # 分配给当前worker的文件
        if worker_info is None:
            files = file_list
        else:
            per_worker = len(file_list) // worker_info.num_workers
            worker_id = worker_info.id
            start = worker_id * per_worker
            end = start + per_worker if worker_id < worker_info.num_workers - 1 else len(file_list)
            files = file_list[start:end]
        
        # 随机打乱
        random.shuffle(files)
        
        # 流式读取
        for file_path in files:
            try:
                if str(file_path).endswith('.h5'):
                    with h5py.File(file_path, 'r') as f:
                        lyso = f['lyso'][:]
                        hpge = f['hpge'][:]
                else:
                    data = np.load(file_path)
                    lyso = data['lyso']
                    hpge = data['hpge']
                
                lyso = lyso.astype(np.float32)
                hpge = hpge.astype(np.float32)
                
                if self.normalize:
                    lyso = lyso / (np.max(lyso) + 1e-8)
                    hpge = hpge / (np.max(hpge) + 1e-8)
                
                lyso_tensor = torch.from_numpy(lyso).unsqueeze(0)
                hpge_tensor = torch.from_numpy(hpge).unsqueeze(0)
                
                yield lyso_tensor, hpge_tensor
                
            except Exception as e:
                continue


class LMDBSpectralDataset(Dataset):
    """使用LMDB数据库存储，极大提升读取速度"""
    
    def __init__(self, lmdb_path, transform=None, normalize=True):
        self.lmdb_path = lmdb_path
        self.transform = transform
        self.normalize = normalize
        
        # 打开LMDB环境
        self.env = lmdb.open(lmdb_path, readonly=True, lock=False,
                            readahead=False, meminit=False)
        
        with self.env.begin(write=False) as txn:
            self.length = txn.stat()['entries'] // 2  # lyso和hpge各占一个entry
    
    def __len__(self):
        return self.length
    
    def __getitem__(self, idx):
        with self.env.begin(write=False) as txn:
            lyso_key = f'lyso_{idx}'.encode()
            hpge_key = f'hpge_{idx}'.encode()
            
            lyso_bytes = txn.get(lyso_key)
            hpge_bytes = txn.get(hpge_key)
            
            lyso_spectrum = np.frombuffer(lyso_bytes, dtype=np.float32)
            hpge_spectrum = np.frombuffer(hpge_bytes, dtype=np.float32)
        
        if self.normalize:
            lyso_spectrum = lyso_spectrum / (np.max(lyso_spectrum) + 1e-8)
            hpge_spectrum = hpge_spectrum / (np.max(hpge_spectrum) + 1e-8)
        
        lyso_tensor = torch.from_numpy(lyso_spectrum).unsqueeze(0)
        hpge_tensor = torch.from_numpy(hpge_spectrum).unsqueeze(0)
        
        if self.transform:
            lyso_tensor = self.transform(lyso_tensor)
            hpge_tensor = self.transform(hpge_tensor)
        
        return lyso_tensor, hpge_tensor
    
    def __del__(self):
        if hasattr(self, 'env'):
            self.env.close()


def create_lmdb_dataset(source_path, lmdb_path, map_size=1e12):
    """将数据转换为LMDB格式"""
    env = lmdb.open(lmdb_path, map_size=int(map_size))
    
    source_path = Path(source_path)
    files = list(source_path.rglob('*.h5')) + list(source_path.rglob('*.npy'))
    
    with env.begin(write=True) as txn:
        for idx, file_path in enumerate(files):
            if idx % 1000 == 0:
                print(f"Processing {idx}/{len(files)}")
            
            if str(file_path).endswith('.h5'):
                with h5py.File(file_path, 'r') as f:
                    lyso = f['lyso'][:].astype(np.float32)
                    hpge = f['hpge'][:].astype(np.float32)
            else:
                data = np.load(file_path)
                lyso = data['lyso'].astype(np.float32)
                hpge = data['hpge'].astype(np.float32)
            
            lyso_key = f'lyso_{idx}'.encode()
            hpge_key = f'hpge_{idx}'.encode()
            
            txn.put(lyso_key, lyso.tobytes())
            txn.put(hpge_key, hpge.tobytes())
    
    env.close()
    print(f"LMDB dataset created at {lmdb_path}")


class PrefetchDataLoader:
    """预取数据加载器，减少I/O等待"""
    
    def __init__(self, dataset, batch_size, num_workers=4, prefetch_factor=2):
        self.dataloader = DataLoader(
            dataset,
            batch_size=batch_size,
            shuffle=True,
            num_workers=num_workers,
            pin_memory=True,
            prefetch_factor=prefetch_factor,
            persistent_workers=True  # 保持worker进程活跃
        )
    
    def __iter__(self):
        return iter(self.dataloader)
    
    def __len__(self):
        return len(self.dataloader)


def create_large_data_loaders(train_path, val_path, batch_size=32, 
                            num_workers=8, use_lmdb=False):
    """创建适合大规模数据的加载器"""
    
    if use_lmdb:
        # 使用LMDB格式
        train_dataset = LMDBSpectralDataset(train_path)
        val_dataset = LMDBSpectralDataset(val_path)
    else:
        # 使用优化的文件读取
        train_dataset = LargeSpectralDataset(train_path)
        val_dataset = LargeSpectralDataset(val_path)
    
    train_loader = PrefetchDataLoader(
        train_dataset,
        batch_size=batch_size,
        num_workers=num_workers
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers//2,
        pin_memory=True
    )
    
    return train_loader, val_loader